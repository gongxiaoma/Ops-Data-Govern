package es

// AliEsSlowSearchLog 定义ES索引结构体
type AliEsSlowSearchLog struct {
	//global.GVA_MODEL，不是MySQL结构，所以不需要依赖基础模型
	EventTime      string  `json:"eventTime"`      // 日志时间
	Timestamp      int64   `json:"@timestamp"`     // 时间戳
	QueryText      string  `json:"queryText"`      // 原始查询语句
	DurationMs     float64 `json:"durationMs"`     // 查询耗时(ms)
	IndexName      string  `json:"indexName"`      // 查询的索引
	NodeIp         string  `json:"nodeIP"`         // 客户端IP
	InstanceId     string  `json:"instanceId"`     // ES集群ID
	Level          string  `json:"level"`          // 日志级别
	SearchHits     float64 `json:"searchHits"`     // 查询命中文档数
	SearchType     string  `json:"searchType"`     // 查询类型
	ShardId        int64   `json:"shardId"`        // 分片ID
	SlowSearchType string  `json:"slowSearchType"` // 慢查询类型
	ShardTotal     int64   `json:"shardTotal"`     // 查询命令分片数
}

func (AliEsSlowSearchLog) TableName() string {
	return "ali_es_slow_search_log" // 虚拟表名，实际使用ES存储
}
