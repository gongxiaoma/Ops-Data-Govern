package es

type ServiceGroup struct {
	AliEsSlowSearchLogService
}
