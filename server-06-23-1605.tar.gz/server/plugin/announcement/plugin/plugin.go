package plugin

import "github.com/flipped-aurora/gin-vue-admin/server/plugin/announcement/config"

var Config config.Config
